module.exports = {
server: {
      options: {
        port: 8080,
        base: ''
      }
    }
};