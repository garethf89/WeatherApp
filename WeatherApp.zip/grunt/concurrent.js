module.exports = {
        dev: {
            tasks: ['connect', 'watch'],
            options: {
                logConcurrentOutput: true
            }
        }
};